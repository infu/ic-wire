#!/usr/bin/env bash
set -euo pipefail
source /tmp/ic-wire-regression-20261028-jKXVdF/env.sh
task_run=/tmp/ic-wire-head-20261028-BqV6wM
task_variant=$1
export TMPDIR="$task_run/temp"
export CARGO_TARGET_DIR="$task_run/target-standard-$task_variant"
if [ "$task_variant" = before ]; then cd "$task_run/upstream"; else cd "$task_run/head"; fi
mkdir -p "$task_run/artifacts/standard"
for task_profile in evaluation benchmark-speed; do
  for task_cohort in standard hotspots; do
    task_features=wire
    if [ "$task_cohort" = hotspots ]; then task_features=wire,hotspots; fi
    cargo build --locked --offline -p ic-wire-benchmarks --example codec-wasm --features "$task_features" --target wasm32-unknown-unknown --profile "$task_profile" > "$task_run/logs/standard-$task_variant-$task_cohort-$task_profile.log" 2>&1
    cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$task_profile/examples/codec_wasm.wasm" "$task_run/artifacts/standard/$task_variant-$task_cohort-$task_profile.wasm"
  done
done
