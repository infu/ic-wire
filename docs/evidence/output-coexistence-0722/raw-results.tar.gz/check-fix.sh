#!/usr/bin/env bash
set -euo pipefail
source /tmp/ic-wire-regression-20261028-jKXVdF/env.sh
task_run=/tmp/ic-wire-head-20261028-BqV6wM
export CARGO_TARGET_DIR="$task_run/target-checks"
export TMPDIR="$task_run/temp"
cd "$task_run/head"
cargo test --locked --offline -p ic-wire --test native > "$task_run/logs/fixed-native-tests.log" 2>&1
cargo test --locked --offline -p ic-wire --doc > "$task_run/logs/fixed-doctests.log" 2>&1
cargo clippy --locked --offline -p ic-wire --lib --test native -- -D warnings > "$task_run/logs/fixed-clippy.log" 2>&1
RUSTUP_TOOLCHAIN=1.91.0 cargo check --locked --offline -p ic-wire --lib --target wasm32-unknown-unknown > "$task_run/logs/fixed-msrv-wasm.log" 2>&1
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$task_run/receipts/fixed-checks-completed.txt"
