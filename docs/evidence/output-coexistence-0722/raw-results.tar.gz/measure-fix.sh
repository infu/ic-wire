#!/usr/bin/env bash
set -euo pipefail
task_profile=$1
task_run=/tmp/ic-wire-head-20261028-BqV6wM
export POCKET_IC_BIN=/srv/shared/code/newstack/playground/private-frozen-binaries/sha256/6a9a75ad9b4551d2b0f4a0d954ffb8bd5bbd0ebc44ac00290679b06ad0b2f8e6/pocket-ic
/tmp/ic-wire-sdk-pr-20261027-rfvGX0/evidence/isolated/instruction-runner --baseline "$task_run/artifacts/head-$task_profile.wasm" --candidate "$task_run/artifacts/fixed-$task_profile.wasm" --output "$task_run/results/fix-$task_profile" --samples 8
