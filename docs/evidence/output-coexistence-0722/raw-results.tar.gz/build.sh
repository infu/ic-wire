#!/usr/bin/env bash
set -euo pipefail
source /tmp/ic-wire-regression-20261028-jKXVdF/env.sh
task_run=/tmp/ic-wire-head-20261028-BqV6wM
task_variant=$1
export TMPDIR="$task_run/temp"
export CARGO_TARGET_DIR="$task_run/target-$task_variant"
cd "$task_run/$task_variant"
git rev-parse HEAD > "$task_run/receipts/$task_variant-head.txt"
git diff --binary > "$task_run/receipts/$task_variant.patch"
sha256sum Cargo.toml Cargo.lock crates/ic-wire/src/native/mod.rs crates/ic-wire-benchmarks/examples/caller_output/mod.rs > "$task_run/receipts/$task_variant-inputs.sha256"
task_features=caller-output
if [ "$task_variant" = old ]; then task_features=caller-output-baseline; fi
for task_profile in benchmark-speed evaluation; do
  cargo build --locked --offline -p ic-wire-benchmarks --example caller-output-wasm --features "$task_features" --target wasm32-unknown-unknown --profile "$task_profile" > "$task_run/logs/build-$task_variant-$task_profile.log" 2>&1
  cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/$task_profile/examples/caller_output_wasm.wasm" "$task_run/artifacts/$task_variant-$task_profile.wasm"
done
